package com.example.diningreview.model;

public enum AdminReviewStatus {
    PENDING,
    APPROVED,
    REJECTED
}
